
# Put the for-loop you made before inside a function.
# Use the same structure as fun1, 
# so copy and modify the first and last lines of this script.
# Call your new function fun2, with one argument called z.

fun2 = function(z)
{
  for(i in 1:length(z))
  {
    if(z[i] < 5 | z[i] > 90){
      z[i] = z[i] * 10
    }else{
      z[i] = z[i] * 0.1
    }
  }
  return(z)
}


