
# define a variable called w
w = 3

if(w < 5){
  d=2
}else{
  d=10
}

# First a condition is specified: w should be less than 5.
# If the condition is met, R will execute what is between the first brackets.
# If the condition is not met, R will execute what is between the second brackets, after the else. 
# You can leave the else{...}-part out if you don't need it.





