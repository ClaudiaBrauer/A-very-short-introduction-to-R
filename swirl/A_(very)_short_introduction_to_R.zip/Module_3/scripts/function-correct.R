fun1 = function(arg1, arg2 )
{
  w = arg1 ^ 2
  return(arg2 + w)
}

# In line 1 the function name (fun1) and its arguments (arg1 and arg2) are defined.
# Lines 2-5 specify what the function should do if it is called. 
# The return value (arg2+w) is given as output.

