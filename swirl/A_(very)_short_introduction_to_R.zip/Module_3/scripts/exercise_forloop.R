
# Replace the ... with the appropriate commands.

# Make vector called z containing numbers from 1 to 100.
...

# Make the for-loop with the range to run over in round brackets, 
# the things to do each run in curly brackets,
# and an if-statement between the curly brackets.

for(i in ...)
{
  if(z[i] < ... | ...){
    z[i] = ...
  }else{
    ...
  }
}
