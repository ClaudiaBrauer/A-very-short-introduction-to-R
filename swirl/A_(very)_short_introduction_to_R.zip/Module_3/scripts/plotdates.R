
# Replace in this script the ... with the appropriate commands.

# Make a vector called dates with the three dates:
# today, Sinterklaas (a Dutch holiday) and your next birthday.
...

# Make a vector called presents with the three expected number of presents.
...

# Plot the dates versus the number of presents.
...

